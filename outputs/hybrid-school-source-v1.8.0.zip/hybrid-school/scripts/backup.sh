#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p backups
umask 077
file="backups/school-$(date -u +%Y%m%dT%H%M%SZ).dump"
docker compose exec -T db sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' > "$file"
test -s "$file"
echo "Backup saved: $file. Copy it to protected off-server storage."
