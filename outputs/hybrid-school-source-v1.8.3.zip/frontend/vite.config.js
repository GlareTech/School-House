import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({ plugins: [react()], server: { proxy: {
  '/api': { target: 'http://127.0.0.1:3000', changeOrigin: false },
  '/socket.io': { target: 'http://127.0.0.1:3000', ws: true, changeOrigin: false }
} } });
