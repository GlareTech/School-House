$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
New-Item -ItemType Directory -Force -Path backups | Out-Null
$backupName = 'school-' + (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ') + '.dump'
docker compose exec -T db sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc -f /tmp/school-backup.dump'
if ($LASTEXITCODE -ne 0) { throw 'Database backup failed' }
docker compose cp db:/tmp/school-backup.dump "backups/$backupName"
if ($LASTEXITCODE -ne 0) { throw 'Backup copy failed' }
Write-Host "Backup saved: backups/$backupName. Copy it to protected off-server storage."
